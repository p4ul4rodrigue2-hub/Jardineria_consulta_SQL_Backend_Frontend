import express from 'express';
import mysql from 'mysql2';
import cors from 'cors';
const app = express();
const port = 3000;

// MIDDLEWARES
app.use(cors());          // 2. Permitir peticiones desde el frontend (Vite)
app.use(express.json());  // 3. ¡IMPORTANTE! Para que Express pueda leer el JSON que envías

const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'Asd.123*',
  database: 'Jardineria'
});

// Esta ruta recibe CUALQUIER query desde el HTML
app.post('/ejecutar-query', (req, res) => {
  const { query } = req.body; 

  connection.query(query, (err, results) => {
    if (err) {
      return res.status(400).send({ error: err.message });
    }
    res.json(results); // Enviamos los datos (filas) de vuelta al HTML
  });
});

app.listen(3000, () => console.log(`Servidor listo en el puerto ${port}`));
