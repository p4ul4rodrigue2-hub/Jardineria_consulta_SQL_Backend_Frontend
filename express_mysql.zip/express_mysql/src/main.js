import './style.css'
// import javascriptLogo from './javascript.svg'
// import viteLogo from '/vite.svg'
// import { setupCounter } from './counter.js'

const btn = document.getElementById('btnEnviar');
const areaTexto = document.getElementById('queryInput');
const tablaCabecera = document.getElementById('tabla_cabecera');
const tablaCuerpo = document.getElementById('tabla_cuerpo');

btn.addEventListener('click', async () => {
    const query = areaTexto.value;
    
    // Limpiamos la tabla antes de una nueva búsqueda
    tablaCabecera.innerHTML = "";
    tablaCuerpo.innerHTML = "";

    try {
        const response = await fetch('http://localhost:3000/ejecutar-query', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ query: query })
        });

        const data = await response.json();

        if (data.length > 0) {
            // 1. Crear los encabezados dinámicamente usando las llaves del primer objeto
            const columnas = Object.keys(data[0]);
            const trHead = document.createElement('tr');
            
            columnas.forEach(col => {
                const th = document.createElement('th');
                th.innerText = col.toUpperCase();
                trHead.appendChild(th);
            });
            tablaCabecera.appendChild(trHead);

            // 2. Crear las filas con los datos
            data.forEach(fila => {
                const tr = document.createElement('tr');
                columnas.forEach(col => {
                    const td = document.createElement('td');
                    td.innerText = fila[col];
                    tr.appendChild(td);
                });
                tablaCuerpo.appendChild(tr);
            });
        } else {
            alert("No se encontraron resultados o la consulta no retornó datos.");
        }
    } catch (error) {
        console.error("Error al obtener datos:", error);
    }
});
